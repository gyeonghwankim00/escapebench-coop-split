"""Split v4 files match their generator and the recorded verification (CPU only, no replays)."""
import hashlib
import json
from pathlib import Path
import unittest

import yaml

import scripts.split_v4 as v4

ROOT = Path(__file__).resolve().parents[1]


class SplitV4Tests(unittest.TestCase):
    def test_game_files_are_reproducible_from_edits(self):
        for game, spec in v4.EDITS.items():
            scenes, ref, dropped, _, _ = v4.edit_game(game, spec)
            self.assertEqual(yaml.safe_load((v4.V4/'games'/f'{game}.yaml').read_text()), scenes, game)
            self.assertEqual(v4.read_reference(v4.V4/'reference'/f'key_log_{spec["ref"]}.txt'), ref, game)
            self.assertEqual(len(dropped), spec['expect_dropped'], game)

    def test_v3_is_untouched_and_v4_covers_only_changed_games(self):
        for game in v4.SPLITS:
            v3 = json.loads((ROOT/'data/roles'/f'{game}.json').read_text())
            self.assertEqual(v3['version'], 'v3')
            spec = json.loads((v4.V4/'roles'/f'{game}.json').read_text())
            self.assertEqual(spec['version'], 'v4')
            self.assertEqual(spec['B'], [n for n in spec['A'] + spec['B'] if n in v4.SPLITS[game]['B']])
        self.assertEqual({p.stem for p in (v4.V4/'roles').glob('*.json')}, set(v4.SPLITS))

    def test_recorded_verification_matches_files(self):
        ver = json.loads((v4.V4/'verification.json').read_text())
        self.assertTrue(ver['passed'])
        self.assertEqual(set(ver['games']), set(v4.SPLITS))
        for game, r in ver['games'].items():
            for f in r['files'].values():
                self.assertEqual(hashlib.sha256((ROOT/f['path']).read_bytes()).hexdigest(), f['sha256'], game)
            self.assertEqual(r['dead_steps'], {'known_codes': [], 'observed_clues': []}, game)
            self.assertTrue(r['solo_replay']['escaped'] and r['peer_replay']['escaped'], game)
            self.assertFalse(r['solo_replay']['partner_area_moves'] or r['peer_replay']['partner_area_moves'], game)
            if game in v4.EDITS:
                # deletions make the file unwinnable alone; moved links only must not
                self.assertEqual(r['original_mode']['v4_file_winnable_alone'], not v4.EDITS[game]['objects'], game)

    def test_clues_drop_only_deleted_objects(self):
        v3 = json.loads((ROOT/'data/clues.json').read_text())['games']
        new = json.loads((v4.V4/'clues.json').read_text())['games']
        for game in v4.SPLITS:
            gone = {o for _, o in v4.EDITS.get(game, {}).get('objects', [])}
            kept = [c for c in v3[game] if c['target'] not in gone and not any(s['object'] in gone for s in c['sources'])]
            self.assertEqual(new[game], kept, game)


if __name__ == '__main__':
    unittest.main()
